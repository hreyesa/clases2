<?php 

$usuario = $this->session->userdata('id_usuario');    

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Home</title>
		
</head>
<body>

<h1>ingreso de usuario</h1>

</body>
</html>
